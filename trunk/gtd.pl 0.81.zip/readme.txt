Perl mobileGTD companion

This Perl script acts as a desktop command line companion to the wonderful mobileGTD app (http://code.google.com/p/mobilegtd).

Basically put it in your ~/bin directory a make it executable (chmod +x). There are some configuration settings at the top of the file that you should look at & modify for your own environment. This includes pathing etc.

Your first step would be to get the files & folders created by mobileGTD onto your desktop, then run:

    gtd help 

    or

    gtd help | less

This will give you all the avialable options & some examples.

As with most things of this nature, make sure you do backups of the mobileGTD files. Have tried to make things as safe as possible, but just to be safe...
