#!/usr/bin/perl 
#===============================================================================
#
#         FILE:  gtd.pl
#
#        USAGE:  ./gtd.pl 
#
#  DESCRIPTION: A desktop command line companion to mobileGTD on a s60 v3 
#               Symbian phone
#
# REQUIREMENTS:  Perl
#       AUTHOR:   (Daryn Hanright), <daz@planetnz.com>
#      VERSION:  0.81
#      CREATED:  16/01/09 15:12:18 NZDT
#     REVISION:  ---
#===============================================================================

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Data::Dumper;

########## config ###########
my $basedir = "/home/user/gtd";
my $dir = "$basedir/\@Projects";
my $syncApp = "sudo /usr/bin/unison";
my $backupApp = "sudo rsync -capz"; 
my $moveApp = "mv";
my $copyApp = "cp";
my $editApp = "vi";
my $remindFile = "/home/user/.reminders";
#############################


########## main ############
# main hash containing list of projects with actions
my %gtd = &readStuff;
my %tday = &getToday;
#print Dumper %gtd;

my $stuffToDo = $ARGV[0];
my $whatToDo = '';
my $p = '';
my $a = '';
my $f = '';
my $s = '';
my $text = '';

my $countArgs = scalar(@ARGV);
my $count = 0;
foreach my $whatToDoItems (@ARGV) {
    $count++;
    #print "$whatToDo\n";
    my ($matchText) = $whatToDoItems =~ m@^[p|f|a|s]:@g;
    if (!$matchText) {
        my ($matchText2) = $whatToDoItems =~ m@^[q-r|g-o|b-e|t-z]:@g;
        if (($count > 1) && (!$matchText2)) {
            $whatToDoItems = "'$whatToDoItems'";
        } else {
            if ($count > 1) {
                cleanUpExit('p, a, s, f, options');
            }
        }
    }
    if ($count == $countArgs) {
        $whatToDo .= $whatToDoItems;
    } else {
        $whatToDo .= $whatToDoItems . " ";
    }
}
if (!$whatToDo) {
    $whatToDo = "'' p: a: f: s: ";
}
if (!$stuffToDo) {
    $stuffToDo = "help";
}

($p) = $whatToDo =~ m@p:(.*?)(\s|$)@g;
($a) = $whatToDo =~ m@a:(.*?)(\s|$)@g;
($f) = $whatToDo =~ m@f:(.*?)(\s|$)@g;
($s) = $whatToDo =~ m@s:(.*?)(\s|$)@g;
($text) = $whatToDo =~ m@'(.*?)'(\s|$)@g;

my $lengthP = 0;
my $lengthA = 0;
my $lengthS = 0;
my $lengthT = 0;

if (defined $p) {
    if ($p =~ /^[+-]?\d+$/ ) {
        $lengthP = length($p);
    }
} 
if (defined $a) {
    if ($a =~ /^[+-]?\d+$/ ) {
        $lengthA = length($a);
    }
}
if ($s) {
    $lengthS = length($s);
}
if (defined $text) {
    if ($text =~ /^[+-]?\d+$/ ) {
        $lengthT = length($text);
    } 
}


if ("list" =~ /^$stuffToDo$/i) { listProjects(); }
elsif ("listall" =~ /^$stuffToDo$/i) { listProjectsWithActions(); }
elsif ("listpa" =~ /^$stuffToDo$/i) { 
    if (($lengthP > 0) || ($lengthS > 0) || ($f)) { 
        listProjectActions($p,$s,$f);
    } else {
        cleanUpExit("p, s, f");
    }
}
elsif ("status" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($lengthS == 1) && ($lengthA > 0)) { 
        changeStatusAction($p,$a,$s);
    } else {
        cleanUpExit("p, s, a");
    }
}
elsif ("name" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text) && ($lengthA > 0)) { 
        changeNameAction($p,$a,$text);
    } else {
        cleanUpExit("p, options, a");
    }
}
elsif ("addp" =~ /^$stuffToDo$/i) {
    if ($text) { 
        addProject ($text);
    } else {
        cleanUpExit("options");
    }
}
elsif ("add" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text) && ($lengthS == 1) && ($f)) { 
        addActionToProject ($s,$text,$f,$p);
    } else {
        cleanUpExit("s,options,f,p");
    }
}
elsif ("dela" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($lengthA > 0)) { 
        deleteAction ($p,$a);
    } else {
        cleanUpExit("a,p");
    }
}
elsif ("delp" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        deleteProject ($p);
    } else {
        cleanUpExit("p");
    }
}
elsif ("edit" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        editProject ($p);
    } else {
        cleanUpExit("p");
    }
}
elsif ("proj" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        projectProcess ($p,"\@Done");
    } else {
        cleanUpExit("p");
    }
}
elsif ("review" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        projectProcess ($p,"\@Review");
    } else {
        cleanUpExit("p");
    }
}
elsif ("defer" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        projectProcess ($p,"\@Someday");
    } else {
        cleanUpExit("p");
    }
}
elsif ("tickle" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        projectProcess ($p,"\@Tickle");
    } else {
        cleanUpExit("p");
    }
}
elsif ("actoday" =~ /^$stuffToDo$/i) { 
    if (($lengthP > 0) && ($lengthA > 0)) { 
        actionToday ($p,$a,"\@Today"); 
    } else {
        cleanUpExit("p, a");
    }
}
elsif ("today" =~ /^$stuffToDo$/i) { whatsToday (); }
elsif ("dtoday" =~ /^$stuffToDo$/i) {
    if ($lengthA > 0) { 
        doneToday ($a); 
    } else {
        cleanUpExit("a");
    }
}
elsif ("info" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text)) { 
        addUpdateInfo ($p,$text);
    } else {
        cleanUpExit("p, options");
    }
}
elsif ("infoa" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text)) { 
        addUpdateInfoAppend ($p,$text);
    } else {
        cleanUpExit("p, options");
    }
}
elsif ("folder" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($f) && ($lengthA > 0)) { 
        changeActionFolder ($p,$a,$f);
    } else {
        cleanUpExit("p, a, f");
    }
}
elsif ("projrn" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text)) { 
        renameProject ($p,$text);
    } else {
        cleanUpExit("p, options");
    }
}
elsif ("other" =~ /^$stuffToDo$/i) { otherStuff (); }
elsif ("act" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        activateProject ($p);
    } else {
        cleanUpExit("p");
    }
}
elsif ("search" =~ /^$stuffToDo$/i) {
    if ($text) { 
        searchProject2 ($text);
    } else {
        cleanUpExit("options");
    }
}
elsif ("sync" =~ /^$stuffToDo$/i) {
    if ($text) { 
        rsyncProject ($text);
    } else {
        cleanUpExit("options");
    }
}
elsif ("backup" =~ /^$stuffToDo$/i) {
    if ($text) { 
        backupStuff ($text);
    } else {
        cleanUpExit("options");
    }
}
elsif ("dump" =~ /^$stuffToDo$/i) {
    if ($lengthP > 0) { 
        dumpActions ($p);
    } else {
        cleanUpExit("p");
    }
}
elsif ("pri" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text) && ($lengthA > 0)) { 
        changePriority ($p,$a,$text);
    } else {
        cleanUpExit("p, a, options");
    }
}
elsif ("remind" =~ /^$stuffToDo$/i) {
    if (($lengthP > 0) && ($text) && ($lengthA > 0)) { 
        setReminder ($p,$a,$text);
    } else {
        cleanUpExit("p, a, options");
    }
}
elsif ("help" =~ /^$stuffToDo$/i) { helpStuff(); }
else { helpStuff(); }
################################################


############## functions #######################
sub helpStuff {
    print "A MobileGTD command line companion written in Perl\n";
    print "By Daryn Hanright\n";
    print "Usage: gtd.pl <Options> <Parameters>\n";
    print "==================================================\n";
    print "Options:\n";
    print "     list - list all projects\n";
    print "     listall - list all projects with actions\n";
    print "     listpa - list all actions for a given project. Can be filtered by status & folder - parameters: p,s,f\n";
    print "     status - change status of action in given project - parameters: p,a,s\n";
    print "     add - add action to project - parameters: option,p,f,s\n";
    print "     addp - add project - parameters: option\n";
    print "     dela - delete action from given project - parameters: p,a\n";
    print "     delp - delete project - parameters: p\n";
    print "     edit - edit project file - parameters: p\n";
    print "     proj - move project to \@Done - parameters: p\n";
    print "     review - move project to \@Review - parameters: p\n";
    print "     defer - move project to \@Someday - parameters: p\n";
    print "     tickle - move project to \@Tickle - parameters: p\n";
    print "     actoday - copy action to \@Today - parameters: p,a\n";
    print "     today - what actions am I doing today\n";
    print "     dtoday - action done today - parameters: a\n";
    print "     projrn - rename project - parameters: p,option\n";
    print "     pri - change priority of action - parameters: p,a, option\n";
    print "     info - add/update info of project - parameters: p,option\n";
    print "     infoa - append infos onto project - parameters: p,option\n";
    print "     other - list projects deferred, in review etc etc\n";
    print "     act - activate project from other - parameters: p\n";
    print "     search - does a search of action & folder names - parameters: option\n";
    print "     sync - does a sync of 2 gtd folders using unison - parameters: option\n";
    print "     backup - copies using rsync gtd folders to another folder - parameters: option\n";
    print "     dump - does a clean output of actions from .prj file - parameters: p\n";
    print "     folder - change folder of action in given project - parameters: p,a,f\n";
    print "     remind - set a reminder for an action - parameters: p,a,options\n";
    print "     name - change name of action of action in given project - parameters: p,a,option\n";
    print "\n";
    print "Parameters:\n";
    print "     p:<n> - project number\n";
    print "     a:<n> - action number\n";
    print "     s:+/-/! - status of project\n";
    print "     f:<n> - folder of project\n";
    print "     option - option to be added. Put broken text within single quotes. Examples are:\n";
    print "         'this is an action'\n";
    print "         /path/to/something\n";
    print "         01\n";
    print "\n";
    print "Example usages:\n";
    print "list all current projects with project numbers (use therefore is p:<n>):\n";
    print "     gtd.pl list\n";
    print "list actions in given project:\n";
    print "     gtd.pl listpa p:0\n";
    print "list actions in given project within a folder:\n";
    print "     gtd.pl listpa p:0 f:FolderName\n";
    print "list actions in given project given a status:\n";
    print "     gtd.pl listpa p:0 s:+\n";
    print "add an action to a project:\n";
    print "     gtd.pl add p:0 f:FolderName s:- 'this is a test action'\n";
    print "delete an action from a project:\n";
    print "     gtd.pl dela p:0 a:2\n";
    print "add a project:\n";
    print "     gtd.pl addp 'project_name'\n";
    print "change status of action:\n";
    print "     gtd.pl status p:0 a:2 s:-\n";
    print "change folder of action:\n";
    print "     gtd.pl folder p:0 a:2 f:NewFolderName\n";
    print "copy action to \@Today:\n";
    print "     gtd.pl actoday p:0 a:2\n";
    print "view actions todo today:\n";
    print "     gtd.pl today\n";
    print "done action from today (get num from 'gtd.pl today'):\n";
    print "     gtd.pl dtoday a:0\n";
    print "change order/priority of action in project list:\n";
    print "eg: move item 23 to 02\n";
    print "     gtd.pl pri p:0 a:23 02\n";
    print "edit project list:\n";
    print "     gtd.pl edit p:0\n";
    print "sync gtd with files on memory card using 'unison':\n";
    print "     gtd.pl sync /path/to/memorycard\n";
    print "backup gtd to somewhere using 'rsync':\n";
    print "     gtd.pl backup /path/to/somewhere\n";
    print "append more info's to project:\n";
    print "     gtd.pl infoa p:0 'DO: Something'\n";
    print "set a reminder using 'remind':\n";
    print "     gtd.pl remind p:0 a:12 '17 Feb 2009 AT 11:55'\n";
    print "\n";
}

sub cleanUpExit {
    my ($validParams) = @_;
    print "Sorry, you entered the wrong parameters. Please try again\n";
    if ($validParams) {
        print "Valid params are: $validParams\n";
    }
    print "\n";
    exit;
}

sub dumpActions {
    my ($countPassed) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 > 0) {
            my $tempAction = $basedir."/".$entryFolder."/".$entryAction.".act";
            if (-e $tempAction) {
                unlink ($tempAction);
            }
            if ($entryStatus eq "-") {
                printAction($entryStatus,$entryAction,$entryFolder,$projectName);
            }
        }
        
    }
}

sub rsyncProject {
    my ($mount) = @_;
    system ("$syncApp $basedir $mount");
}

sub backupStuff {
    my ($mount) = @_;
    system ("$backupApp $basedir $mount");
}

# list all projects with actions
sub searchProject2 {
    my ($term) = @_;
    my $countProjects = 0;
    print "============================\n";
    print "Search for $term has found:\n";
    while (my ( $key, $value ) = each(%gtd)) {
        foreach my $key3 (sort (keys(%$value))) {
            my $entryStatus = $value->{$key3}->{"status"};
            my $entryAction = $value->{$key3}->{"action"};
            my $entryFolder = $value->{$key3}->{"folder"};
            my $entryDo = $value->{$key3}->{"do"};
            if ($entryAction) {
                my ($termExistsAction) = $entryAction =~ m@$term@gi;
                my ($termExistsFolder) = $entryFolder =~ m@$term@gi;
                if (($termExistsAction) || ($termExistsFolder)) {
                    if ($entryDo) {

                    } else {
                        print "\[$countProjects\] $key\n   \[$key3\] $entryStatus $entryAction (\@$entryFolder)\n";
                    }
                }
            }
        }
        $countProjects++;
    }
    print "============================\n";
    print "\n";
}

sub whatsToday {
    print "============================\n";
    print "Actions TODO today:\n";
    foreach my $key3 (sort (keys(%tday))) {
        print "\[$key3\] $tday{$key3}\n";
    }
    print "============================\n";
    print "\n";
}

sub todaysDate {
    (my $day, my $month, my $year) = (localtime)[3,4,5];
    my @months = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
    $month = $months[$month];
    $year = 1900 + $year;
    my $today = "$day $month $year";
    return $today;
}

sub doneToday {
    my ($actionPassed) = @_;
    foreach my $key3 (sort (keys(%tday))) {
        if ($actionPassed == $key3) {
            my $del = $tday{$key3} . ".act";
            unlink ("$basedir/\@Today/$del");
            # add to .reminders as a todo history
            my $today = &todaysDate;
            open (FILE, ">>$remindFile");
            print FILE "REM " . $today . " MSG done:" . $tday{$key3} . "%\n";
            close FILE;
        }
    }
}

sub otherStuff {
    my @all = &getOtherStuff();    
    my $num = 0;
    print "============================\n";
    print "Projects Done, Deferred etc:\n";
    foreach my $files (@all) {
        my ($matching) = $files =~ m@\.prj$@g;
        if ($matching) {
            my ($dir,$fileName) = split '\^',$files;
            print "\[$num\] $dir - $fileName\n";
            $num++;
        }
    }
    print "\n";
}

sub activateProject {
    my ($countPassed) = @_;
    my @all = &getOtherStuff();
    my $num = 0;
    foreach my $files (@all) {
        my ($matching) = $files =~ m@\.prj$@g;
        if ($matching) {
            my ($dirTemp,$fileName) = split '\^',$files;
            $fileName =~ s@ @\\ @g;
            if ($num == $countPassed) { 
                system ("$moveApp $dir/$dirTemp/$fileName $dir");
            }
            $num++;
        }
    }
}

sub getOtherStuff {
    opendir (D1, "$dir/\@Review");
    my @f1 = readdir(D1);
    closedir (D1);
    my $i = 0;
    foreach my $t1 (@f1) {
        $f1[$i] = "\@Review^" . $t1;
        $i++;
    }
    opendir (D2, "$dir/\@Done");
    my @f2 = readdir(D2);
    closedir (D2);
    $i = 0;
    foreach my $t2 (@f2) {
        $f2[$i] = "\@Done^" . $t2;
        $i++;
    }
    opendir (D3, "$dir/\@Someday");
    my @f3 = readdir(D3);
    closedir (D3);
    $i = 0;
    foreach my $t3 (@f3) {
        $f3[$i] = "\@Someday^" . $t3;
        $i++;
    }
    opendir (D4, "$dir/\@Tickle");
    my @f4 = readdir(D4);
    closedir (D4);
    $i = 0;
    foreach my $t4 (@f4) {
        $f4[$i] = "\@Tickle^" . $t4;
        $i++;
    }
    my @all = (@f1,@f2,@f3,@f4);
    return @all;
}

sub getToday {
    opendir (D1, "$basedir/\@Today");
    my @f1 = readdir(D1);
    closedir (D1);
    my %tday = ();
    my $i = 0;
    foreach my $t1 (@f1) {
        my ($matching) = $t1 =~ m@\.act$@g;
        if ($matching) {
            $t1 =~ s@.act@@g;
            $tday{$i} = $t1;
            $i++;
        }
    }
    return %tday;
}

sub readStuff {
    opendir (DIR, $dir);
    my @FILES = readdir(DIR);
    closedir(DIR);
    my %gtd = ();
    my @gtdData = ();
    my $infoData = '';
    my $countLinesInfo = 0;
    my $i = 0;
    foreach my $files (@FILES) {
        my ($matching) = $files =~ m@\.prj$@g;
        if ($matching) {
            open (DAT, $dir."/".$files) || die ("Could not open file");
            $files =~ s@\.prj@@g; 
            @gtdData=<DAT>;
            for ($i = 0; $i < @gtdData; $i++ ) {
                my $data = $gtdData[$i];
                my ($status) = $data =~ m@^[!+-]\s+@g;
                my ($folder) = $data =~ m@^[!+-]\s+(.*?)\s+@g;
                my $tempdata = $data;
                $tempdata =~ s@^[!+-]\s+@@g;
                if ($folder) {
                    $tempdata =~ s@^$folder@@g;
                }
                $tempdata =~ s/^\s+//;
                $tempdata =~ s/\s+$//;
                if ($status) {
                    $status =~ s/^\s+//;
                    $status =~ s/\s+$//;
                    my $testI = $i - ($countLinesInfo-1);
                    my ($testi) = $testI =~ m@^\d$@;
                    if ($testi) {
                        $testI = "0" . $testI;
                    }
                    $gtd{$files}{$testI}{"status"} = $status; 
                    $gtd{$files}{$testI}{"action"} = $tempdata;
                    $gtd{$files}{$testI}{"folder"} = $folder;
                } else {
                    $infoData .= $data;
                    $countLinesInfo++;
                }
            }
            $gtd{$files}{00}{"do"} = $infoData; 
            $infoData = '';
            $countLinesInfo = 0;
            close(DAT);
            $i = 0;
        }
    }
    return %gtd;
}

# list all projects
sub listProjects {
    my $countProjects2 = 0;
    print "======================================\n";
    print "Current Projects:\n";
    while (my ( $key, $value ) = each(%gtd)) {
        print "\[$countProjects2\] $key\n";
        $countProjects2++;
    }
    print "======================================\n";
    print "\n";
}

sub addProject {
    my ($title) = @_;
    my $file = $dir . "/" . $title . ".prj";
    open (DAT, ">$file") || die ("Could not open file");
    print DAT "# DO: put desctiption of project here\n";
    close(DAT);
}

sub renameProject {
    my ($countPassed,$newProjectName) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $countPassed) {
            my $projFile = $dir."/".$newProjectName.".prj";
            unlink ($dir."/".$projectName.".prj");
            printProject($projFile, %$project);
            printAction($entryStatus,$entryAction,$entryFolder,$newProjectName);
        }
    }
}

# list all projects with actions
sub listProjectsWithActions {
    my $countProjects = 0;
    while (my ( $key, $value ) = each(%gtd)) {
        print "======================================\n";
        print "$countProjects - $key\n";
        foreach my $key3 (sort (keys(%$value))) {
            my $entryStatus = $value->{$key3}->{"status"};
            my $entryAction = $value->{$key3}->{"action"};
            my $entryFolder = $value->{$key3}->{"folder"};
            my $entryDo = $value->{$key3}->{"do"};
            if ($entryDo) {
                print "$entryDo";
            } else {
                print "\[$key3\] $entryStatus $entryAction (\@$entryFolder)\n";
            }
        }
        if ($countProjects == 0) {
            print "======================================\n";
        }
        print "\n";
        $countProjects++;
    }
}

sub changePriority {
    my ($countPassed,$actionPassed,$priority) = @_;
    my $entryStatusMove = '';
    my $entryActionMove = '';
    my $entryFolderMove = '';
    my $priorityExists = 0;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        if ($key3 == $actionPassed) {
            $entryStatusMove = $project->{$key3}->{"status"};
            $entryActionMove = $project->{$key3}->{"action"};
            $entryFolderMove = $project->{$key3}->{"folder"};
            delete $project->{$key3};
            $priorityExists = 1;
        }
    }
    if ($priorityExists) {
        foreach my $key3 (reverse sort (keys(%$project))) {
            my $entryStatus = $project->{$key3}->{"status"};
            my $entryAction = $project->{$key3}->{"action"};
            my $entryFolder = $project->{$key3}->{"folder"};
            my ($testi) = $priority =~ m@^\d$@;
            if ($testi) {
                $priority = "0" . $priority;
            }
            if ($key3 >= $priority) {
                my $newkey3 = $key3 + 1;
                my ($testKey3) = $newkey3 =~ m@^\d$@;
                if ($testKey3) {
                    $newkey3 = "0" . $newkey3;
                }
                $project->{$newkey3}->{"status"} = $entryStatus;
                $project->{$newkey3}->{"action"} = $entryAction;
                $project->{$newkey3}->{"folder"} = $entryFolder;
                delete $project->{$key3}; 
            }
        }
        $project->{$priority}->{"status"} = $entryStatusMove;
        $project->{$priority}->{"action"} = $entryActionMove;
        $project->{$priority}->{"folder"} = $entryFolderMove;
        my $projFile = $dir."/".$projectName.".prj";
        printProject($projFile, %$project);
    }
}

sub getListProjects {
    my ($countPassed) = @_;
    my @returnedStuff = ();
    my $lengthCount = length($countPassed);
    if ($lengthCount < 1) {
        cleanUpExit ("need to pass a p");
    }
    my $countProjects = 0;
    my $projectName = '';
    while (my $key = each(%gtd)) {
        if ($countPassed == $countProjects) {
            $projectName = $key;
        }
        $countProjects++;
    }
    my $project = $gtd{$projectName};
    push (@returnedStuff,$project);
    push (@returnedStuff,$projectName);
    push (@returnedStuff,$countProjects);
    return @returnedStuff;
}


# list given project with actions
# example - list project 0
sub listProjectActions {
    my ($countPassed,$statusPassed,$folderPassed) = @_;
    if (!$statusPassed) {
        $statusPassed = "all";
    }
    if (!$folderPassed) {
        $folderPassed = "all";
    }
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
#    my $countProjects = 0;
#    my $projectName = '';
#    while (my $key = each(%gtd)) {
#        if ($countPassed == $countProjects) {
#            $projectName = $key;
#        }
#        $countProjects++;
#    }
#    my $project = $gtd{$projectName};
    print "======================================\n";
    print "Project: \[$countPassed\] $projectName\n";
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        my $entryDo = $project->{$key3}->{"do"};
        if ($entryDo) {
            print "$entryDo\n";
        } else {
            if (($statusPassed eq $entryStatus) && ($folderPassed eq $entryFolder)) {
                print "\[$key3\] $entryStatus $entryAction (\@$entryFolder)\n";
            } 
            if (($statusPassed eq $entryStatus) && ($folderPassed eq "all")) {
                print "\[$key3\] $entryStatus $entryAction (\@$entryFolder)\n";
            }
            if (($folderPassed eq $entryFolder) && ($statusPassed eq "all")){
                print "\[$key3\] $entryStatus $entryAction (\@$entryFolder)\n";
            }
            if (($statusPassed eq "all") && ($folderPassed eq "all")){
                print "\[$key3\] $entryStatus $entryAction (\@$entryFolder)\n";
            }
        }
    }
    print "======================================\n";
    print "\n";
}

# change status of action within project
sub changeStatusAction {
    my ($countPassed,$actionPassed,$actionChange) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $actionPassed) {
            my $projFile = $dir."/".$projectName.".prj";
            $project->{$key3}->{"status"} = $actionChange;
            printProject($projFile, %$project);
            if (($actionChange eq '+') || ($actionChange eq '!')){
                deleteActionFolder($countPassed,$actionPassed);
            } else {
                printAction($actionChange,$entryAction,$entryFolder,$projectName);
            }

        }
    }
}

# change status of action within project
sub changeNameAction {
    my ($countPassed,$actionPassed,$actionChange) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $actionPassed) {
            my $projFile = $dir."/".$projectName.".prj";
            $project->{$key3}->{"action"} = $actionChange;
            printProject($projFile, %$project);
            printAction($actionChange,$entryAction,$entryFolder,$projectName);
        }
    }
}

# change status of action within project
sub setReminder {
    my ($countPassed,$actionPassed,$reminder) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $actionPassed) {
            open (FILE, ">>$remindFile");
            print FILE "REM " . $reminder . " MSG " . $entryAction . "%\n";
            close FILE;
        }
    }
}

sub changeActionFolder {
    my ($countPassed,$actionPassed,$folderChange) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $actionPassed) {
            my $projFile = $dir."/".$projectName.".prj";
            my $oldFolder = $project->{$key3}->{"folder"};
            $project->{$key3}->{"folder"} = $folderChange;
            printProject($projFile, %$project);
            if (-d $basedir . "/" . $folderChange) {
                # print "everything cool";
            } else {
                mkdir $basedir . "/" . $folderChange or die;
            }
            $entryAction =~ s@ @\\ @g;
            system ("$moveApp " . $basedir . "/" . $oldFolder . "/" . $entryAction . ".act " .  $basedir . "/" . $folderChange);
        }
    }
}

# delete action
sub deleteAction {
    my ($countPassed,$actionPassed) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $actionPassed) {
            delete $project->{$key3}; 
            my $projFile = $dir."/".$projectName.".prj";
            printProject($projFile, %$project);
            unlink ($basedir."/".$entryFolder."/".$entryAction.".act");
        }
    }
}

sub deleteActionFolder {
    my ($countPassed,$actionPassed) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($key3 == $actionPassed) {
            unlink ($basedir."/".$entryFolder."/".$entryAction.".act");
        }
    }
}
# delete project
sub deleteProject {
    my ($countPassed) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    my $projFile = $dir."/".$projectName.".prj";
    unlink ($projFile);
}

# delete project
sub editProject {
    my ($countPassed) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    my $projFile = $dir."/".$projectName.".prj";
    $projFile =~ s@ @\\ @g;
    system ("$editApp $projFile");
}

sub addUpdateInfo {
    my ($countPassed, $info) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    my $projFile = $dir."/".$projectName.".prj";
    my $data = '';
    open (FILE, "<$projFile");
    read FILE, $data, 100000;
    close FILE;
    open (FILE, ">$projFile");
    my ($matchDO) = $data =~ m@^#(.*)@g;
    if ($matchDO) {
        $data =~ s@$matchDO@ $info@g;
        print FILE $data;
    } else {
        print FILE "# DO: " . $info . "\n" . $data;
    }
    close FILE;
}

sub addUpdateInfoAppend {
    my ($countPassed, $info) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    my $projFile = $dir."/".$projectName.".prj";
    my $data = '';
    my $entryAction = $project->{0}->{"do"};
    $entryAction = $entryAction . "# " . $info . "\n";
    $project->{0}->{"do"} = $entryAction;
    printProject($projFile, %$project);
}

sub projectProcess {
    my ($countPassed,$folder) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    my $projFile = $dir."/".$projectName.".prj";
    $projFile =~ s@ @\\ @g;
    if (-d $dir . "/$folder") {
        #print "everything good";
    } else {
        mkdir $dir . "/$folder" or die;
    }
    system ("$moveApp $projFile $dir/$folder");
}

sub actionToday {
    my ($countPassed, $actionPassed, $folder) = @_;
    my @return = &getListProjects($countPassed);
    my $project = $return[0];
    my $projectName = $return[1];
    if (-d $basedir . "/$folder") {
        #print "everything good";
    } else {
        mkdir $basedir . "/$folder" or die;
    }
    foreach my $key3 (sort (keys(%$project))) {
        my $entryStatus = $project->{$key3}->{"status"};
        my $entryAction = $project->{$key3}->{"action"};
        my $entryFolder = $project->{$key3}->{"folder"};
        if ($entryAction) {
            $entryAction =~ s@ @\\ @g;
        }
        if ($key3 == $actionPassed) {
            system ("$copyApp $basedir/$entryFolder/$entryAction.act $basedir/$folder");
        }
    }
}

# print out project
sub printProject {
    my ($passedFile, %passedGTD) = @_;
    my $tempFile = $passedFile;
    $tempFile =~ s@ @\\ @g;
    open (DAT, ">$passedFile") || die ("Could not open file");
    foreach my $key3 (sort (keys(%passedGTD))) {
        my $projStatus = $passedGTD{$key3}{"status"};
        my $projAction = $passedGTD{$key3}{"action"};
        my $projFolder = $passedGTD{$key3}{"folder"};
        my $projDo = $passedGTD{$key3}{"do"};
        if ($key3 == 0) {
            print DAT "$projDo";
        } else {
            print DAT "$projStatus $projFolder $projAction\n";
        }
    }
    close(DAT);
}

sub printAction {
    my ($entrystatus,$entryaction,$entryfolder,$projectname) = @_;
    my $file = $basedir . "/" . $entryfolder . "/" . $entryaction . ".act";
    open (DAT, ">$file") || die ("Could not open file");
    print DAT "$entrystatus $entryfolder $entryaction\n";
    print DAT "Project: $projectname";
    close(DAT);
}

sub addActionToProject {
    my ($entrystatus,$entryaction,$entryfolder,$projectcount) = @_;
    my $countProjects = 0;
    my $projectName = '';
    while (my $key = each(%gtd)) {
        if ( $projectcount == $countProjects) {
            $projectName = $key;
        }
        $countProjects++;
    }
    my $proj = $dir."/".$projectName.".prj";
    my $file = $basedir . "/" . $entryfolder . "/" . $entryaction . ".act";
    if (-d $basedir . "/" . $entryfolder) {
        # print "everything cool";
    } else {
        mkdir $basedir . "/" . $entryfolder or die;
    }
    open (FILE, ">>$proj") || die ("Could not open file");
    print FILE "$entrystatus $entryfolder $entryaction\n";
    close(FILE);
    if ($entrystatus ne "+") {
        open (DAT, ">$file") || die ("Could not open file");
        print DAT "$entrystatus $entryfolder $entryaction\n";
        print DAT "Project: $projectName";
        close(DAT);
    }
}
#######################################################
