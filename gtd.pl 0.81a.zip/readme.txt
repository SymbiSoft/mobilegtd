Perl mobileGTD companion

gtd.pl
======
This Perl script acts as a desktop command line companion to the wonderful mobileGTD app (http://code.google.com/p/mobilegtd).

Basically put it in your ~/bin directory a make it executable (chmod +x). There are some configuration settings at the top of the file that you should look at & modify for your own environment. This includes pathing etc.

Your first step would be to get the files & folders created by mobileGTD onto your desktop, then run:

    gtd.pl help 

    or

    gtd.pl help | less

This will give you all the availlable options & some examples.

As with most things of this nature, make sure you do backups of the mobileGTD files. Have tried to make things as safe as possible, but just to be safe...

gtdmutt
=======
This is just a wee wrapper that uses a mutt macro to capture to STDOUT an selected email, grab its subject line, & use that as the text for an action. Just also drop it into your ~/bin directory & chmod +x it.

In your .muttrc put something like this in there:
macro index "<Esc>3" "|gtd list" "/home/user/bin/gtd.pl list"
macro index "<Esc>4" "|gtdmutt " "/home/user/bin/gtdmutt <p> <folder> <optional text>"

Now by pressing ESC-3, you'll be able to see a list of your projects so you know the project number. Then by pressing ESC-4 on a selected email, gtdmutt is activated so you can add the email's subject line as an action on a project.

usage:
    gtdmutt <p> <folder>

or if you wanted to add your own text for the action:
    gtdmutt <p> <folder> '<text>'

eg - add selected email to project [1] in folder Dev:  
    gtdmutt 1 Dev

using gtd.pl in windows
=======================

Have successfully run gtd.pl on windows by installing cygwin.

Just needed to change a copy of lines for apps & base directories:

my $basedir = "c:/gtd";
my $syncApp = "/cygdrive/c/Program\\ Files/Beyond\\ Compare\\ 2/BC2.exe";
my $editApp = "/cygdrive/c/Program\\ Files/Vim/vim71/gvim.exe";

and a small change to not exclude windows file paths (c: etc)
my ($matchText2) = $whatToDoItems =~ m@^[q-r|g-o|b|d-e|t-z]:@g;

Obviously remind won't work, but you could hack the setReminder function to put the action into outlook pretty easily.

